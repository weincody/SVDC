gsa.message <- function(message) {
    message(sprintf("[gsalib] %s", message));
}
